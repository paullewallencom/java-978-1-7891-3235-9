package com.packt.cookbook.ch04_functional.c.api;

public interface Car extends Vehicle {
    int getPassengersCount();

}
