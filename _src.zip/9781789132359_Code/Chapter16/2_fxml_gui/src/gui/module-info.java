module gui{
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.fxml;

	opens com.packt;
}