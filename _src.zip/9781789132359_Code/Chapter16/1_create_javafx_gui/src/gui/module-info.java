module gui{
	requires javafx.graphics;
	requires javafx.controls;

	exports com.packt;
}