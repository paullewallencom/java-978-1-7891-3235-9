package com.packt.processor;

public enum ParentEducation{
	NONE, PRIMARY, FIVE_NINE_GRADE, SECONDARY, HIGHER;
}