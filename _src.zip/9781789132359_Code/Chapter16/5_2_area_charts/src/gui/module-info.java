module gui{
	requires javafx.graphics;
	requires javafx.controls;

	opens com.packt;
}