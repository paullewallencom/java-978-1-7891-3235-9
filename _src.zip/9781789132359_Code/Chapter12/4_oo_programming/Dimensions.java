public class Dimensions{
	public int length;
	public int width;
	public int height;

	public Dimensions(){}

	public Dimensions(int length, int width, int height){
		this.length = length;
		this.width = width;
		this.height = height;
	}
}