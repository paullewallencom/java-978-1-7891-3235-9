module jshell{
	requires jdk.jshell;
}