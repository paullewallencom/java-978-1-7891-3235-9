package com.packt.cookbook.ch15_new_way.c_enum.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}
