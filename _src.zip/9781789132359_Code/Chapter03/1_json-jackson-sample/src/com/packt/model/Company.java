package com.packt.model;

public class Company{
	public String name;
	public String catchPhrase;
	public String bs;
}