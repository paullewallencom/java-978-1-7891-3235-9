package com.packt.model;

public class Geo{
	public String lat;
	public String lng;
}