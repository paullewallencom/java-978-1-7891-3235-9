package com.packt.model;

public enum UserPrivilege{
	can_create_post, can_manage_post, can_comment_on_post;	
}