package com.packt.model;

public class Book{
	public Book(String id, String title, String author){
		this.id = id;
		this.title = title;
		this.author = author;
	}
	
	public String id;
	public String title;
	public String author;
}