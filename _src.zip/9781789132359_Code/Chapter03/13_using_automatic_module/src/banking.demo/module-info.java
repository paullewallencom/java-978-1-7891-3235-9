module banking.demo{
    requires com.packt.banking;
}