module simple.module{
    requires jackson.databind;
    requires simple.util;
}