package com.packt.util;

import java.util.*;
public class SimpleModularUtil{
    public String message(){
        return "Hello World in JSON";
    }
}