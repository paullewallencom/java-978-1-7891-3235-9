package com.packt;


public class FactoryDemo{
	public static void main(String[] args){
		System.out.println(CollectionUtil.list("element1", "element2", "element3"));
		System.out.println(CollectionUtil.set("element1", "element2", "element3"));
	}

}