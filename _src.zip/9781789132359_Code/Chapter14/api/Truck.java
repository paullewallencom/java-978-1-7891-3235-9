package com.packt.cookbook.ch14_testing.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}
