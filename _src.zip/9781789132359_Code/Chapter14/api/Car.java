package com.packt.cookbook.ch14_testing.api;

public interface Car extends Vehicle {
    int getPassengersCount();

}
