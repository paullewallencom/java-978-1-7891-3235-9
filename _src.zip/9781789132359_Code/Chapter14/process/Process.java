package com.packt.cookbook.ch14_testing.process;

public enum Process {
    AVERAGE_SPEED,
    TRAFFIC_DENSITY
}
