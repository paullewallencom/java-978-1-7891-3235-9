echo "Running tree command";
tree;
sleep 5;
echo "Running iostat command";
iostat;