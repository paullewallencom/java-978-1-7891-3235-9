package com.packt.boot_rest_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMultiProfileDemo {

	public static void main(String[] args) {
		SpringApplication.run(BootMultiProfileDemo.class, args);
	}
}
