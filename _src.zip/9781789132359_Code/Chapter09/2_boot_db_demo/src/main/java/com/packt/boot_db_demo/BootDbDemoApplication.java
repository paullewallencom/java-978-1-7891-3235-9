package com.packt.boot_db_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDbDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDbDemoApplication.class, args);
	}
}
