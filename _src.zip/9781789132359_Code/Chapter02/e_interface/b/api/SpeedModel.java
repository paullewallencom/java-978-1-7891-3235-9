package com.packt.cookbook.ch02_oop.e_interface.b.api;

public interface SpeedModel {
    double getSpeedMph(double timeSec, int weightPounds, int horsePower);
}
