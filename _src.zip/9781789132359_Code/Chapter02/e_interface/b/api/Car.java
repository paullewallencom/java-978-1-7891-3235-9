package com.packt.cookbook.ch02_oop.e_interface.b.api;

public interface Car extends Vehicle {
    int getPassengersCount();
}
