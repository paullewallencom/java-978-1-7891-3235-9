module http.client.demo{
    requires java.net.http;
    requires jackson.databind;
    requires jackson.core;
    requires jackson.annotations;
}