module http.client.demo{
    requires httpasyncclient;
    requires httpclient;
    requires httpmime;
    requires json;
    requires unirest.java;
    requires httpcore;
    requires httpcore.nio;
    requires commons.logging;
    requires commons.codec;
}